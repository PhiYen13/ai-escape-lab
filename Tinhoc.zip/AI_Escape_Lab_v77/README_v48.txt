v48 – Room 03 lớp 3
- Thân máy hư và webcam: trên bàn giữa bên trái cùng màn hình bình thường.
- Chuột bình thường: trên bàn giữa bên phải cùng thân máy và máy in.
- Màn hình hư: dưới sàn giữa phía trên.
- Các vị trí còn lại, hình nền, gameplay và các phòng khác giữ nguyên từ v47.
Mở index.html để chơi; điều khiển WASD/mũi tên và E.
