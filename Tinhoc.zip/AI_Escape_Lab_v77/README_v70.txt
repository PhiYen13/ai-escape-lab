v70: Ẩn thanh điều hướng tại màn hình chọn lớp; hiển thị Cài đặt và Chơi lại trên trang chủ; thêm nút Trang chủ ở bản đồ; sao vàng trên đúng cửa đã hoàn thành, không dùng dấu tích.
