AI Escape Lab v71: Sửa lỗi chọn lớp không mở bản đồ do mã JS tham chiếu nút #grade-back đã bị xóa ở v70. Giữ nguyên toàn bộ dữ liệu và các nhiệm vụ.
