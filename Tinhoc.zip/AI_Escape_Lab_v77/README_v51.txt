AI Escape Lab v51 — Room 03 / Chặng 2
- Hành lang minh họa 2D đồng bộ, ba trạm tự do.
- Robot Byte giới thiệu nhiệm vụ và củng cố kiến thức sau mỗi trạm.
- Laptop touchpad, máy tính bảng có 4 biểu tượng (chọn bóng đèn), điện thoại bàn phím QWERTY.
- Giữ các hoạt động 1, 3, 4 và tiến độ cũ.
Mở index.html?teacher=1 để kiểm tra.
