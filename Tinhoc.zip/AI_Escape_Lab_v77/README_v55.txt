v55: Hoạt động 3 — Xưởng phân loại thiết bị. Kéo thả 5 thiết bị vào các nhóm chức năng, chuyển động băng chuyền và phản hồi. Giữ nguyên hoạt động 1,2,4.
