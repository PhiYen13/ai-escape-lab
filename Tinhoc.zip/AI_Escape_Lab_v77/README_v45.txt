v45: Đã sửa nền Khu A thành đúng ảnh nền kho thiết bị có bàn, kệ và cửa đỏ được thống nhất. Điều chỉnh vị trí 16 đối tượng PNG theo các mặt bàn và kệ. Các phòng khác giữ nguyên.
