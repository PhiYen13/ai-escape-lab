AI Escape Lab v65 - Room 03, activities 3 and 4
- New approved backgrounds, no baked-in progress tracker.
- Existing code-rendered progress panel retained.
- Activity 3: conveyor controls aligned to background; randomized drag-and-drop remains.
- Activity 4: hazards aligned to loose socket (left), drink and dusty keyboard (center), unsafe cable (right).
- Rooms 01, 02 and other stages unchanged.
