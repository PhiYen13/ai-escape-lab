v56: Sửa chồng lấn HUD 4 chặng với tiến độ 3 hệ thống ở hoạt động 2; khi kéo thả thiết bị băng chuyền, hình được đưa lên lớp trên cùng để không bị che bởi khung và thùng.
