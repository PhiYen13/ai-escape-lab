AI Escape Lab v64 – Khôi phục tiến độ Hoạt động 3 và 4.

- Loại bỏ vùng nền bị làm mờ trong v63; giữ hình nền sắc nét.
- Chỉ hiển thị một bảng tiến độ động 4 chặng, không chồng lên số tiến độ vẽ sẵn.
- Giữ nguyên các sửa lỗi kéo thả, nút vận hành và vùng nguy cơ không phát sáng trước khi xử lý.
- Room 04 vẫn khóa đến khi hoàn thành Room 03.

Đã kiểm tra cú pháp JS và ZIP; chưa kiểm thử trực quan trên trình duyệt.
