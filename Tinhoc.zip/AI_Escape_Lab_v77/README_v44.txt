AI Escape Lab v44 – Room 03 lớp 3

16 thiết bị PNG trong assets/room3_devices/.
4 bộ phận cần tìm: màn hình, thân máy, bàn phím, chuột.
12 vật gây nhiễu: 4 thiết bị còn hoạt động khác và 8 thiết bị hư.
Dùng WASD/phím mũi tên, E tương tác.
Mở index.html?teacher=1 để thử Room 03.
Room 01–02 giữ nguyên.
